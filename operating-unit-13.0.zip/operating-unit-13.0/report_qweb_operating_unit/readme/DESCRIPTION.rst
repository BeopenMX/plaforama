This module allows to use custom operating unit headers for any report in Odoo
