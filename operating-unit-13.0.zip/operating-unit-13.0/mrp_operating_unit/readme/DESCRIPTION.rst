This module introduces the following features:

* Adds Operating Unit (OU) to the Manufacturing Order created from the procurement.

* This module implements global security rules on manufacturing orders so that a user can only read manufacturing orders where the location is linked to an
  operating unit that the user has access to.
