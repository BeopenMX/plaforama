Follow these steps to make it working:

#. Go to Reordering Rules
#. Create a new Rule for the product you want to create the Manufacturing Order
#. Run the scheduler
