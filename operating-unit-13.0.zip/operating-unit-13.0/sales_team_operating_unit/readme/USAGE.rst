Add the operating unit to sales team
