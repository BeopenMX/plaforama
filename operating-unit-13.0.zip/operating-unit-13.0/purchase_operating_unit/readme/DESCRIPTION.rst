This module introduces the following features:

- It introduces the operating unit to the purchase order.
- The operating unit is copied to the invoice.
- The operating unit is copied to the stock picking.
- It implements user's security rules.
