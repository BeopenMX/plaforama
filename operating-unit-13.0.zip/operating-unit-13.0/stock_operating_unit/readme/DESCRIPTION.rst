This module introduces the following features:

- Adds the operating unit to the Warehouse.
- Adds the operating unit to the Stock Location.
- Adds the requesting operating unit to stock pickings.
- Implements user's security access rules.
