The Manager can see the stock rules of other Operating Units but he can not
edit them. If he tries to access to one of these stock rules, he will receive
a configuration error.
