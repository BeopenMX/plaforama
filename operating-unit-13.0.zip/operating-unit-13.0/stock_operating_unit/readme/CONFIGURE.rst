To configure this module, you need to:

* Assign Operating Unit to Warehouses.
* Assign Operating Unit to Stock Locations.
